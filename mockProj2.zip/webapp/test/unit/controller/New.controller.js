/*global QUnit*/

sap.ui.define([
	"mp2/mockProj2/controller/New.controller"
], function (Controller) {
	"use strict";

	QUnit.module("New Controller");

	QUnit.test("I should test the New controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});