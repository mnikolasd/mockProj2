sap.ui.define([
	"mp2/mockProj2/test/unit/controller/New.controller"
], function () {
	"use strict";
});