sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("mp2.mockProj2.controller.New", {
		onInit: function () {
			var complete_url = window.location.href;
			var pieces = complete_url.split("?");
			var params = pieces[2].split("&");
			var oData = [];
			$.each( params, function( key, value ) {
				var param_value = value.split("=");
				oData.push({ key: key, name: param_value[1] });
			});
			
			this.getView().byId("input1").setValue(oData[0].name);
			this.getView().byId("input2").setValue(oData[1].name);
			this.getView().byId("input3").setValue(oData[2].name);
			this.getView().byId("input4").setValue(oData[3].name);
			this.getView().byId("input5").setValue(oData[4].name);
			this.getView().byId("input6").setValue(oData[5].name);
		}
	});
});