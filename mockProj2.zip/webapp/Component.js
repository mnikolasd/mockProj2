sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"mp2/mockProj2/model/models"
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("mp2.mockProj2.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			// var oComponentData = this.getComponentData();
			// if (oComponentData.startupParameters) {
			// 	if (sap.ui.core.getHashChanger().getHash() === "") {
			// 		// if no inner app route present, navigate 
			// 		oRouter.navTo("SomeView", {
			// 			someId: oComponentData.startupParameters.someID[0],
			// 		}, false);
			// 	}
			// }
		}
	});
});